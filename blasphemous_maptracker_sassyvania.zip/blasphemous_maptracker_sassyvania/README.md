# Blasphemous Randomizer Map Tracker by Sassyvania

Blasphemous Randomizer
https://www.nexusmods.com/blasphemous/mods/15

Poptracker 
https://github.com/black-sliver/PopTracker

This is my first map tracker, and there's gonna be so many mistakes. Let me know about them! Sassyvania@gmail.com // Saskrotch#3206

First of all I want to give a huge thank you to Demajen, whose tireless work on extremely complete metroidvania maps, including Blasphemous, made this tracker way less of a headache than it would've been, and for sending me a higher quailty, complete, blank map to work with. 

https://demajen.co.uk/

And a hefty thank you to Damocles03, not just for making the randomizer, but for helping me with any logic questions I had. 

And also a big smoochy thank you to br00ty and j_im for helping me with my newbie baby codey questions!

## Installation

Unzip into poptracker's "packs" folder. That's it! On macOS you'll find the packs folder by right clicking on poptracker.app, clicking Show Package Contents, and navigating to Contents>MacOS>Packs.

## Notes
1) Jibrael quest is not included yet. The Amanecida verses & Aubade of the Nameless Guardian reward are not yet randomized. I'll probably add this in a later version whether they get randomized or not, tbh.
2) Quests! There's a few checks on the map that don't actually give you an in game item, but they add a hidden item to the tracker inventory to unlock the next step of a quest. Right now this includes Cleofas, Esdras and his Sister, the Miriam crossover event, and Redento (although he is visible because I love the lil guy).

## To-Do

This is an EXTREMELY beta version of the tracker. It's messy and probably got some stuff wrong with it. I just wanted to get it out as soon as it was usable and leave other stuff later. Here's what I've got planned for future releases

Vertical Item Tracker
Cleaning up The Items
Evening out the locations so they don't look all wobbly
Auto-tracking? (I have no idea where to even start with this right now, feel free to give me a push in the right direction, or if you want to collab on it, let me know!)

## License

Feel free to use this template without credit for all your PopTracker packs!