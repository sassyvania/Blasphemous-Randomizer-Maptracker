# Discord Webhook Action

This is the discord webhook action I use to automatically post updates of my pack to discord.

Requires the Webhook URL to be placed in a repo secret on github named ``DISCORD_WEBHOOK_URL``.

Feel free to use as you see fit.